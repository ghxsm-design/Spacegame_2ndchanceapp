SECOND CHANCE — MK5
===================

HOW TO RUN
1. Extract second_chance_mk5.zip.
2. Open the second_chance_mk5 folder in VS Code.
3. Open index.html with Live Server (recommended), or open index.html in a modern browser.
4. Select the Mars Polar Lander campaign and complete the engineering decisions.
5. Open MISSION REVIEW and choose PLAY THE MISSION.

CAMPAIGN CONTROLS
LAUNCH / FLIGHT
- SPACE: launch / ignite (when launch phase is active)
- LEFT / RIGHT or A / D: steer the launch vehicle
- 1, 2, 3: separate the three core stages in the recommended order
- Use the on-screen buttons to progress from transfer to Mars entry and landing.

MARS SURFACE
- W / A / S / D or arrow keys: drive the rover in 2D
- SYSTEMS / POWER: open inventory and power allocation
- MISSION CONTROL: view telemetry from Earth
- END SURFACE MISSION: send the campaign to the mission review board
- REPLAY FROM EARTH: restart the campaign with a fade transition

MK5 FEATURES
- Warmer yellow / gold pixel interface and denser star fields.
- Collapsible icon rail for the nine engineering departments; hover/focus to expand headings and progress bars.
- Launch and transfer sequence with steering and prompted 1/2/3 core separation.
- Mars landing sequence and 2D rover driving.
- Equipment inventory toggles, subsystem power sliders and thermal-heater mode.
- Rover battery and temperature telemetry, mission events and Earth mission-control panel.
- Mission review board with multiple verdict categories and replay.

NOTE
This is an educational game prototype. Engineering resource values, mission events,
flight controls, system behaviours and review-board scoring are simplified fictional
game mechanics. They are not flight software, real spacecraft specifications, or
operational guidance for an actual launch or landing.
