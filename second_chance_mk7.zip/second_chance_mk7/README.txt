SECOND CHANCE — MK7 / PHOENIX CAMPAIGN

WHAT CHANGED IN MK7
- Calmer deep teal / turquoise mission-control palette; removed the warm yellow/brown overrides.
- Larger, more prominent department and resource icons with reduced label density.
- Engineering design now happens after Month 0 trajectory selection and before the Earth launch gameplay.
- Restored the engineering layout: department icon rail on the LEFT, Mars scene in the CENTRE, design decisions on the RIGHT.
- Rebuilt the trajectory graphic as a Sun-centred orbital diagram with circular Earth and Mars orbits, Mars's launch-window lead position, an elliptical transfer arc and an animated spacecraft travelling along the arc.
- FAST uses a different transfer arc; STANDARD and HEAVY LIFT use the reference ellipse. The diagram is schematic and game-scaled, not a flight-planning tool.

FILES
- index.html
- style.css (MK5 base styling)
- app.js (MK6 game logic)
- mk6.css / mk6.js (MK6 systems)
- mk7.css / mk7.js (MK7 refinements)

RUN
1. Extract the ZIP.
2. Open the folder in VS Code.
3. Run index.html with Live Server, or open it in a modern browser.
4. Internet is needed for Google Fonts; local fallback fonts are provided.

CAMPAIGN FLOW
Intro → Month 0 trajectory choice → Engineering campaign → Engineering review → Earth launch → Mars mission.

NOTE
The orbital illustration is an educational schematic. It illustrates a Sun-centred elliptical transfer between idealised circular planetary orbits. It is not numerically integrated and should not be presented as a real ephemeris or operational trajectory. FAST / STANDARD / HEAVY LIFT values are fictional game-balancing choices.
